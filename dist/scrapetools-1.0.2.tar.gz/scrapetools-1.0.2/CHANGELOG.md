# Changelog

## 1.0.1 (2023-01-31)

#### Performance improvements

* increase number of tags and attributes LinkScraper processes when looking for urls
#### Others

* update to build v1.0.1

Full set of changes: [`v1.0.0...1.0.1`](https://github.com/matt-manes/scrapetools/compare/v1.0.0...1.0.1)

## v1.0.0 (2023-01-21)

