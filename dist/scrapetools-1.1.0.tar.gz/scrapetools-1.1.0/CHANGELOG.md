# Changelog

## 1.0.2 (2023-02-23)

#### Fixes

* fix stripping one too many ch in strip_unicode
#### Others

* add changelog
* update readme


## v1.0.1 (2023-01-31)

#### Performance improvements

* increase number of tags and attributes LinkScraper processes when looking for urls
#### Others

* update to build v1.0.1


## v1.0.0 (2023-01-21)
